[![fair-software.eu](https://img.shields.io/badge/fair--software.eu-%E2%97%8F%20%20%E2%97%8B%20%20%E2%97%8B%20%20%E2%97%8B%20%20%E2%97%8B-red)](https://fair-software.eu)
[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.15249204.svg)](https://doi.org/10.5281/zenodo.15249204)
[![FAIR‑software checklist](https://img.shields.io/badge/FAIR--software%20checklist-✓%20%20✓%20%20✓%20%20✓%20%20✓-green)](https://fair-software.eu/checklist/)
